for p in com.android.hotwordenrollment.xgoogle com.android.hotwordenrollment.okgoogle; do pm enable "$p" >/dev/null 2>&1; done
