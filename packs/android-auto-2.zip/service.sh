#!/system/bin/sh
# Keep the DSP hotword providers off (an app update could re-enable them); see customize.sh
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
for p in com.android.hotwordenrollment.xgoogle com.android.hotwordenrollment.okgoogle; do pm disable "$p" >/dev/null 2>&1; done
