# Android Auto add-on: (1) system/product/priv-app/AndroidAutoStub (Samsung's stub, debloated from the ROM) makes the
# Play Store Android Auto an updated privileged app, so it gets MANAGE_USB for the car connection; (2) below:
# "Hey Google" on the audio DSP resets the tablet: the Google app loads its hotword model onto Xiaomi's ADSP through
# Samsung's sound trigger stack, the ADSP crashes and takes USB/charging down with it (seen when Android Auto starts).
# Disable the DSP hotword model providers; Assistant keeps working from the mic button.
for p in com.android.hotwordenrollment.xgoogle com.android.hotwordenrollment.okgoogle; do pm disable "$p" >/dev/null 2>&1; done
ui_print "- DSP \"Hey Google\" turned off"
