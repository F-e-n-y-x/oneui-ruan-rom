#!/system/bin/sh
# Ruan Fixes > "Wireless ADB" (global ruan_adb_wifi=1): adb on TCP port 5555 after every start. Settings are up only after boot.
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
if [ "$(settings get global ruan_adb_wifi)" = 1 ]; then
    setprop service.adb.tcp.port 5555
    setprop ctl.restart adbd
fi
