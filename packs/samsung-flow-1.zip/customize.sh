# Samsung Flow refuses to start on a rooted device: it runs `su` and looks for su files. Hide root from Samsung Flow
# only (Magisk Zygisk + DenyList); every other app, Ruan Fixes and adb keep root. Applies after the restart.
magisk --sqlite "REPLACE INTO settings (key,value) VALUES('zygisk',1)"
magisk --denylist enable
magisk --denylist add com.samsung.android.galaxycontinuity
ui_print "- Root hidden from Samsung Flow only (restart to apply)"
