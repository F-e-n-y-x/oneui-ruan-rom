# Pack removed: Samsung Flow sees root again (Zygisk stays on, harmless without modules using it)
magisk --denylist rm com.samsung.android.galaxycontinuity
