#!/system/bin/sh
# USB debugging at boot on b39 (b40 has this in ruan_vendor_fixes.rc). Samsung persists "sec_charging[,adb]", which the
# Xiaomi gadget HAL rejects; and nothing starts adbd for "mtp,adb" (Samsung commented out init's rules, usbd only
# handles exactly "adb"), so USB debugging stayed off until toggled.
c=$(getprop persist.sys.usb.config)
case "$c" in
    sec_charging,adb) c=mtp,adb; setprop persist.sys.usb.config $c ;;
    sec_charging) c=mtp; setprop persist.sys.usb.config $c ;;
esac
case ",$c," in *,adb,*) setprop ctl.start adbd ;; esac
