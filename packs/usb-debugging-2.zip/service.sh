#!/system/bin/sh
# Root for `adb shell su` (uid 2000), like Ruan Fixes > "Root for ADB shell" on b40. Settings are up only after boot.
# Skipped when that switch was turned off (global ruan_root_adb=0); OR IGNORE keeps a deny set in Magisk.
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
[ "$(settings get global ruan_root_adb)" = 0 ] ||
    magisk --sqlite "INSERT OR IGNORE INTO policies (uid,policy,until,logging,notification) VALUES(2000,2,0,1,1)"
